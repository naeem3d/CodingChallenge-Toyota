//
//  CodingChallenge_ToyotaApp.swift
//  CodingChallenge-Toyota
//
//  Created by naeem alabboodi on 8/25/23.
//

import SwiftUI

@main
struct CodingChallenge_ToyotaApp: App {
    var body: some Scene {
        WindowGroup {
            StandurdView()
        }
    }
}
